package com.example.laba4_1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Додаємо фрагменти статично через FragmentManager
        if (savedInstanceState == null) {
            supportFragmentManager.commit {
                replace(R.id.fragment1_container, Fragment1())
                replace(R.id.fragment2_container, Fragment2())
                replace(R.id.fragment3_container, Fragment3())
                replace(R.id.fragment4_container, Fragment4())
            }
        }
    }
}
